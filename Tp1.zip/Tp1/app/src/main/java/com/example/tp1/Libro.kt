package com.example.tp1

data class Libro(
    val titulo: String,
    val autor: String,
    val anio: Int,
    val genero: String,
    val isbn: String,
    val portadaUrl: String
)
